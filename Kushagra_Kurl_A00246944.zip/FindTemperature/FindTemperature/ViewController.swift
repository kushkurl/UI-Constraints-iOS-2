

//
//  ViewController.swift
//  DropDown
//
//  Created by Amsaraj Mariappan on 4/9/2562 BE.
//  Copyright © 2562 Amsaraj Mariyappan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    
    @IBOutlet weak var showResult: UILabel!
    @IBOutlet weak var degree: UITextField!
    
    var selectedType: String?
    
    @IBAction func calcTemp(_ sender: Any) {
        var result = 0
        if let degree = Int(degree.text!) {
            if textFiled.text == "Fahrenhiet" {
                result = (degree * 9/5) + 32
            } else if textFiled.text == "Celcius"{
                result = (degree - 32) * 5/9
            }else {
                result = degree
            }
            showResult.text = "\(result)"
        }else {
            showResult.text = "NULL"
        }
    }
    
    
    var typeList = ["Fahrenhiet", "Celcius"]
    
    @IBOutlet weak var textFiled: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createPickerView()
        dismissPickerView()
        degree.delegate = self
        textFiled.delegate = self
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return typeList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return typeList[row]
       
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedType = typeList[row]
        textFiled.text = selectedType
    }
    
    func createPickerView() {
        let pickerView = UIPickerView()
        pickerView.delegate = self
        textFiled.inputView = pickerView
    }
    
    func dismissPickerView() {
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let button = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.action))
        toolBar.setItems([button], animated: true)
        toolBar.isUserInteractionEnabled = true
        textFiled.inputAccessoryView = toolBar
    }
    
    @objc func action() {
       view.endEditing(true)
    }


}


